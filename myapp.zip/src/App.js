import logo from './logo.svg';
import './App.css';


import './bootstrap/dist/css/bootstrap.min.css'
import Nav from './Components/calender'
import Signup from './Components/sidenav'


import {Router, Route } from 'react-router-dom';
import { Simulate } from 'react-dom/cjs/react-dom-test-utils.development';
import Dnd from './Components/calender';


function App() {
  return (
    
    <div className='row m-2'style={{height: "calc(100vh - 17px)"}}>
      
    <Signup/>
     <Dnd/>
    </div>
  );
}
export default App;
